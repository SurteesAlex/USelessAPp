﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Useless_App
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Useless2 ub = new Useless2();
            ub.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Useless3 uc = new Useless3();
            uc.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Useless4 ud = new Useless4();
            ud.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Useless1 ua = new Useless1();
            ua.Show();
        }
    }
}
