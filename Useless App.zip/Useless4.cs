﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Useless_App
{
    public partial class Useless4 : Form
    {
        public Useless4()
        {
            InitializeComponent();
        }
        public string otherThing = "";

        string[] facts = { "A Greek-Canadian man invented the “Hawaiian” pizza.", "Messages from your brain travel along your nerves at up to 200 miles per hour.", "Rubber bands last longer when refrigerated.", "Peanuts are one of the ingredients of dynamite.", "A cat has 32 muscles in each ear.", "An ostrich’s eye is bigger than its brain.", "The microwave was invented after a researcher walked by a radar tube and a chocolate bar melted in his pocket.", "The only domestic animal not mentioned in the Bible is the cat.", "Cats can’t taste sweet things because of a genetic defect.", "Around 16 million people alive today are direct descendants of Genghis Khan.", "Your own dead skin cells make up the majority of the dust in your house.", "Your cellphone carries up to ten times more bacteria than a toilet seat.", "A Human has fewer chromosomes than a potato.", "Statistically, you are more likely to die on the way to buy a lottery ticket than you are to win the lottery itself." }; //"o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "!", "@", "#", "$", "%", "d", "^", "&", "*", "(", ")" };
        Random rnd = new Random();

        private void button1_Click(object sender, EventArgs e)
        {
            otherThing = "";

            int pIndex = rnd.Next(facts.Length);

            otherThing += facts[pIndex];

            textBox1.Text = otherThing;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu m = new Menu();
            m.Show();
        }
    }
}
